package org.suggs.katas.jmsbroker.operations;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.suggs.katas.jmsbroker.connection.JMSConfig;

/**
 *
 * Generic class to send message from queue
 *
 * @author Sanjeev_Bharti
 *
 */
@Component
public class Sender {

	@Autowired
	private JMSConfig jmsConfig;
	private MessageProducer messageProducer;


	public void sendMessage(Session session, Destination queue, String message) throws JMSException {
		messageProducer = jmsConfig.createMessageProducer(session, queue);
		messageProducer.send(jmsConfig.getTextMessage(session,message));
	}
}
